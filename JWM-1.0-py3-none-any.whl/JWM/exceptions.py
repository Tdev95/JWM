class JWMException(Exception):
    pass


class DeserializationException(JWMException):
    pass
